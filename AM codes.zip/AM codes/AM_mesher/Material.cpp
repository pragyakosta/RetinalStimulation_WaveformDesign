// Material.cpp: implementation of the CMaterial class.
// Carlos J. Cela, 2004
//////////////////////////////////////////////////////////////////////
#include "Material.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMaterial::CMaterial(const std::complex<float>& mx, const std::complex<float>& my, const std::complex<float>& mz)
{
    x = mx;
    y = my;
    z = mz;

}

CMaterial::~CMaterial()
{

}
