//////////////////////////////////////////////////////////////////////
// Material.h: interface for the CMaterial class.
// Carlos J. Cela, 2004
//////////////////////////////////////////////////////////////////////
// Represents a type of material. x, y & z are the complex 
// unitary impedance or admittance components for each axis.
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MATERIAL_H__03D17155_8BF1_44D8_8D25_0151EF49071D__INCLUDED_)
#define AFX_MATERIAL_H__03D17155_8BF1_44D8_8D25_0151EF49071D__INCLUDED_

#include <complex>

class CMaterial  
{
public:
	CMaterial(const std::complex<float>& mx, const std::complex<float>& my, const std::complex<float>& mz);
	virtual ~CMaterial();

	// The values below are the of a 1x1m section,
	// having a thickness of 1m
    std::complex<float> x;
    std::complex<float> y;
    std::complex<float> z;
};

#endif // !defined(AFX_MATERIAL_H__03D17155_8BF1_44D8_8D25_0151EF49071D__INCLUDED_)
