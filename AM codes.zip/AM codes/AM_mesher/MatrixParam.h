// MatrixParam.h: interface for the CMatrixParam class.
// C.J. Cela, 2004,2005
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MATRIXPARAM_H__31D2E533_8D48_4CEF_BCE4_1BD3A442D90D__INCLUDED_)
#define AFX_MATRIXPARAM_H__31D2E533_8D48_4CEF_BCE4_1BD3A442D90D__INCLUDED_

#pragma warning(disable: 4786)

#include <complex>
#include <list>

#include "FileReader.h"
#include "Material.h"
#include "Volume.h"
#include <map>
#include "Util.h"
#include "Node.h"

class CMatrixParam  
{
public:
    CMatrixParam( std::string inFileName);
	CMatrixParam( CFileReader& infile);
	virtual ~CMatrixParam();

    // Returns true if data is good
    bool isValid();

    // List materials
    void debugDump();

    // Max of x,y or z world dimensions
    int getWorldSize();

    const std::string& getNodeName(std::string& alias);
    const std::string& getNodeAlias(std::string& name);
    bool hasAlias(std::string& name);


   ////////////////////////////////////////////////
    // Parameters read from the *.in file below
    ////////////////////////////////////////////////

    // File names & file load behavior
    std::string networkFile;
    std::string matrixFile;
    std::string meshFile;
    std::string inFile;
    std::string ispreadFile;
    std::string nodeVoltageFile;
    int loadBehavior;

    // World size/offset 
    int worldSizeX;
    int worldSizeY;
    int worldSizeZ;

    // List of materials
    std::map<const int, CMaterial*> material;
    int defaultMaterial;

    // Maps of node names & aliases (for reverse lookup)
    std::map<std::string, std::string*> nodeName;
    std::map<std::string, std::string*> nodeAlias;

    // Sources & references
    std::list<std::string*> spice;
    std::string nodePrefix;
    int nodePrefixLen;

    // Frequency for calculating the model
    float frequency;

    // List of volumes
    std::list<CVolume*> volume;


    // Voxel sizes
    float unitVoxelSize;// Unit voxel size, in meters
    int maximumSize;    // Overall max size, in unit voxels
    int restrictedSize; // Max size in restricted region, in unit voxels

    // Clustering & boundaries
    int boundaryCriteria;
    int clusteringGeometry;
    int clusteringRatio;


private:
    bool valid; // True if parameters are coherent.

    // Load/parse from *.in file
    void initialize(CFileReader& file); 
    void parseFileParams(CFileReader& file);
    void parseWorldParams(CFileReader& file);
    void parseRegionParams(CFileReader& file);
    void parseMaterialParams(CFileReader& file);
    void parseVoxelParams(CFileReader& file);
    void parseClusteringParams(CFileReader& file);

    // Helpers
    std::string getDefaultFilename();
    void replaceNodeNames(std::string& cs);

};

#endif // !defined(AFX_MATRIXPARAM_H__31D2E533_8D48_4CEF_BCE4_1BD3A442D90D__INCLUDED_)
