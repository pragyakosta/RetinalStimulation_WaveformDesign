//////////////////////////////////////////////////////////////////////
// mesh.h
// Carlos J. Cela, 2010
//////////////////////////////////////////////////////////////////////
// Mesh manager class. Owns the mesh and performs all the
// related operations on mesh nodes. 
//////////////////////////////////////////////////////////////////////

#if !defined(MESH_H)
#define MESH_H

#include "Node.h"
#include "MatrixParam.h"

class CMesh  
{
public:
  //////////////////////////////////////////////////////
  // Set ups an octree large enough to accomodate a
  // cubic matrix of sideRes cubic cells per side. 
  //
  // resX: Number of unit cells for X side
  //////////////////////////////////////////////////////
	CMesh( int resX, int resY, int resZ );
	~CMesh();
  
  //////////////////////////////////////////////////////
  //  As a 3D matrix, go to a specific cell 
  //  and set/get node. setNode will replace an
  // existing node if needed.
  //////////////////////////////////////////////////////
  void setNode(int x, int y, int z, CNode* node);
  CNode* getNode(int x, int y, int z);
  
  //////////////////////////////////////////////////////
  // Cluster mesh
  //
  // This is here instead of in the CMesher class for 
  // performance reasons. This routine clusters voxels
  // into multiresolution voxels. Level is the clustering
  // level (1 = max size 2^1, etc).
  //////////////////////////////////////////////////////
  bool cluster(int level);
  
  //////////////////////////////////////////////////////
  // Determines if a node is a boundary node and marks
  // it accordingly.
  //////////////////////////////////////////////////////
  void markNodeIfBoundary(int x, int y, int z);
  
  //////////////////////////////////////////////////////
  // Writes mesh to stream
  //////////////////////////////////////////////////////
  int writeMesh( std::ostream& os );

  CMatrixParam* param;
  
private:
  
  // Print voxel debug info
  void list(const char* t, CNode* n);

  // Attach (cluster) 2 nodes. n1 is maintained and
  // expanded, n2 is deleted.
  void attachX(int index1, int index2);
  void attachY(int index1, int index2);
  void attachZ(int index1, int index2);
  
  // Return requested node if position is also
  // node origin; otherwise returns a null pointer.
  CNode* getNodeIfOrigin(int x, int y, int z);
  
  // Attemp to cluster voxels in one direction
  void tryClusterX(bool& r);
  void tryClusterY(bool& r);
  void tryClusterZ(bool& r);
  
  // Check constraints for clustering 2 voxels
  bool checkConstraintsX(CNode* n1, CNode* n2);  
  bool checkConstraintsY(CNode* n1, CNode* n2);  
  bool checkConstraintsZ(CNode* n1, CNode* n2);  
  
  // Clusters a group of 8 octants centered on x, y, z,
  // as best as possible. SideSize is the side size of the
  // volume to consider. 
  bool clusterVoxels(int x, int y, int z, int sideSize);
  
  // Check that voxel can be clustered. Size and position are of target MR voxel.
  bool checkGeometricConstraints(int x, int y, int z, int sx, int sy, int sz);
  
  // Return size of smallest side of any neighbor voxel
  // of given voxel
  int getSizeOfSmallestNeighbor(int x, int y, int z, int sx, int sy, int sz);
  
  // Return smallest size of a voxel if less than the
  // actual value of s
  void getSmallestSize(int x, int y, int z, int& s);
  
  // Return smallest of 3 numbers
  inline int smallestOf(int x, int y, int z);
  
  // Return smallest of 3 numbers
  int largestOf(int x, int y, int z);
  
  // Return index for given node coordinates
  int getNodeIndex(int x, int y, int z);
  
  // The Mesh!
  CNode** mesh;
  CNode*  octant[8];// Octant indexes are such as lower-left-back voxel is 0.
                    // Bottom indexes:
                    //                0 2
                    //                1 3
                    // Top indexes:
                    //                4 6
                    //                5 7
  
  // Size of the mesh
  int meshSize;
};
#endif // MESH_H