//////////////////////////////////////////////////////////////////////
// Mesher.h: interface for the CMesher class.
// Carlos J. Cela
// Revision date: July 27, 2010
//////////////////////////////////////////////////////////////////////

#include "Mesh.h"
#include "MatrixParam.h"
#include "FileReader.h"
#include "Node.h"

#if !defined(MESHER_H)
#define MESHER_H

class CMesher  
{
public:
	CMesher();
	virtual ~CMesher();

  //////////////////////////////////////////////////
  // Loads *.in file, sets operating params.
  // Needs to be called once before ANY file 
  // operation below is attempted.
  //////////////////////////////////////////////////
  void initialize(const std::string& inFile  = 0);

  // Allocates mesh
  void initMesh();
  
  // Chunk operations - initialize() before using
  void loadMesh();


  // Clustering 
  void cluster();

  // Whole multires mesh file saving - initialize() before using
  void writeMultiresMesh();

  // Free tree memory  
  void deleteMesh(){delete mesh; mesh = 0;};  

private:
  CMesh* mesh;
  CMatrixParam* matrixParam;
  CFileReader matrixFile;

  
  // Marks boundary voxel
  void markBoundaryVoxels();

  // Called only from constructors
  void initTree();


};

#endif // !defined(MESHER_H)
