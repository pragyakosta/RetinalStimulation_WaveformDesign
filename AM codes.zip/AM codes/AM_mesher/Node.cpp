// Node.cpp: implementation of the CNode class.
// Carlos J. Cela, 2004
//////////////////////////////////////////////////////////////////////
#include "Node.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CNode::CNode(short materialCode, short px, short py, short pz, short sizex, short sizey, short sizez):material(materialCode),
x(px),y(py),z(pz),sx(sizex),sy(sizey),sz(sizez),state(ST_AVAILABLE)
{
}

CNode::~CNode()
{
}

