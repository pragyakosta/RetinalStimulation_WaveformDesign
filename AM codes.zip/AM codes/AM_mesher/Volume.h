// Volume.h: interface for the CVolume class.
// C.J. Cela, 2004
//////////////////////////////////////////////////////////////////////

#if !defined(VOLUME_H)
#define VOLUME_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CVolume  
{
public:
	CVolume();
    virtual ~CVolume();

    bool inVolume(int xc, int yc, int zc);

    int px,py,pz;
    int sx,sy,sz;
    int maxSize;
    int clusteringRatio;
};

#endif // !defined(AFX_VOLUME_H__D75D9C23_A9B4_4601_BFB1_BDD625DDBA28__INCLUDED_)
