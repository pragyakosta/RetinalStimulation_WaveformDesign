// Mesher.cpp
// (c) Carlos J. Cela
// Revision date: July 2010
//////////////////////////////////////////////////////////////////////
#include "Mesher.h"
#include "FileReader.h"
#include "Exception.h"
#include "Node.h"
#include "LongHash.h"
#include <iostream>
#include <fstream>
#include <sstream> 
#include "Util.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMesher::CMesher()
{
  mesh = 0;
  matrixParam = 0;
}

CMesher::~CMesher()
{
  if( matrixParam )
    delete matrixParam;
  if( matrixFile.isOpen() )
    matrixFile.close();
  if (mesh )
    delete mesh;
}


void CMesher::initialize(const std::string& inFile)
{
  // Parse *.in file now
  CFileReader fp;
  if(!fp.open(inFile))
    throw CException("Cannot open infile");

  if( matrixParam )
    delete matrixParam;

  matrixParam = new CMatrixParam( fp );
  
  fp.close();

  // Verify *.in file was ok
  if( !matrixParam->isValid() )
    throw CException("Invalid parameters in infile");
}


void CMesher::initMesh()
{ 
  util::msg()<<"Filename check: "<< matrixParam->matrixFile.c_str()<<"\n\n";
  if( !matrixFile.isOpen() ){
	
    if( !matrixFile.open( matrixParam->matrixFile.c_str()) )
	  
      throw CException("matrix file not found.");
    
    util::msg()<<"\n\nOpening matrix file: "<<matrixParam->matrixFile.c_str()<<"\n\n";
  }
  matrixFile.gotoBof();
  matrixFile.getNextLine();

  // Mesher takes world size from *.in file
  if( matrixParam->worldSizeX == 0 ){
    matrixParam->worldSizeX = matrixFile.getInt();
    matrixParam->worldSizeY = matrixFile.getInt();
    matrixParam->worldSizeZ = matrixFile.getInt();
  }

  util::msg()<<"Matrix size is ["<<matrixParam->worldSizeX<<","<<matrixParam->worldSizeY<<","<<matrixParam->worldSizeZ<<"]\n";

  // Init mesh now
  if( mesh ){
    delete mesh;
    mesh = 0;
  }
  mesh = new CMesh( matrixParam->worldSizeX, matrixParam->worldSizeY, matrixParam->worldSizeZ ); 
  
  // Share matrix parameters
  mesh->param = matrixParam;
}


void CMesher::loadMesh()
{
  CNode* newNode;
  std::map<std::string, std::string*>::iterator it;
  CLongHash lh;

 
  // Load mesh now
  int materialCode;
  util::msg()<<"Loading mesh and marking named nodes...\n";
  for( int z = 0; z<matrixParam->worldSizeZ; z++) {
    for( int y = 0; y<matrixParam->worldSizeY; y++ ) { 
      for( int x = 0; x<matrixParam->worldSizeX; x++) {
        // Create node
        materialCode = matrixFile.getInt();
        newNode = new CNode( materialCode, x, y, z, 1, 1, 1 );
        
        // Mark as BOUNDARY if named, so node
        // is guaranteed to be there in the network
        it = matrixParam->nodeName.find(lh.getHash(x,y,z));
        if( it!=matrixParam->nodeName.end() )
          newNode->state = ST_BOUNDARY;
        else
          newNode->state = ST_AVAILABLE;
        
        // Set now
        mesh->setNode(x,y,z,newNode); 
      }
    }
  }
}


void CMesher::markBoundaryVoxels()
{
  util::msg()<<"Marking boundaries...\n";

  // Walk the entire mesh, considering the 3x3x3 volume 
  // surrounding  each voxel.
  for( int z = 0; z<matrixParam->worldSizeZ; z++){
    for( int y = 0 ; y<matrixParam->worldSizeY; y++){
      for(int x = 0 ; x<matrixParam->worldSizeX; x++){
        mesh->markNodeIfBoundary(x, y, z);
      }
    }
  }
}


void CMesher::writeMultiresMesh()
{
    // Open file
    std::filebuf fb;
    fb.open (matrixParam->meshFile.c_str(),std::ios::out);
    std::ostream os(&fb);

    // Write header record
    // os<<"%MRM-V1.0 "<<matrixParam->inFile<<"\n";

    // Dump tree to file
    int numVoxels = mesh->writeMesh( os );
    util::msg()<<numVoxels<<" voxels written to file.\n";

    // Close file
    fb.close();
}


void CMesher::cluster()
{
  // iterate n times, up to 2^n >= maxSize, to
  // allow clusters to grow to that size.
  int i=1;
  util::msg()<<"Processing entire model\n";

  markBoundaryVoxels();
  while(mesh->cluster(i)){
    util::msg()<<"Clustering iteration #"<<i<<"\n";
    i++;  
  }
}


