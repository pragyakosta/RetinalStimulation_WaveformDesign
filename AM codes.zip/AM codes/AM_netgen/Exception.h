// Exception.h: interface for the CException class.
// C.J. Cela, 2004
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EXCEPTION_H__B51FC5A8_310F_47C5_9791_C092675AC29B__INCLUDED_)
#define AFX_EXCEPTION_H__B51FC5A8_310F_47C5_9791_C092675AC29B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CException  
{
public:
	CException(const char* errorDescription);
	virtual ~CException();

};

#endif // !defined(AFX_EXCEPTION_H__B51FC5A8_310F_47C5_9791_C092675AC29B__INCLUDED_)

