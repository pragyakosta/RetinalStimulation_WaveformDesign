// FileReader.cpp: implementation of the CFileReader class.
// C.J. Cela, 2004
//////////////////////////////////////////////////////////////////////

#include "FileReader.h"
#include <stdlib.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFileReader::CFileReader()
{
    stream = 0;
    mark = 0;
    thisFile="";
}

CFileReader::~CFileReader()
{
    close();
}
bool CFileReader::open(const char* filename,bool binary)
{
  if( stream != 0)
      return false;
  if( binary )
      stream = new std::ifstream(filename,std::ios::in | std::ios::binary);
  else
      stream = new std::ifstream(filename);

  thisFile = filename;
  return isOpen();
}

bool CFileReader::open(const std::string& filename,bool binary)
{
  if( stream != 0)
      return false;
  if( binary )
      stream = new std::ifstream(filename.c_str(),std::ios::in | std::ios::binary);
  else
      stream = new std::ifstream(filename.c_str());

  thisFile = filename;
  return isOpen();
}

std::string CFileReader::getFileName(){
    return thisFile;
}

void CFileReader::close()
{
    if( stream!=0 ){
        stream->close();
        delete stream;
        stream = 0;
    }
}
bool CFileReader::isOpen()
{
    if( stream == 0 )
        return false;
    return stream->is_open();
}

void CFileReader::gotoBof()
{
    stream->clear();
    stream->seekg(0,std::ios_base::beg);
}
void CFileReader::getCurrentLine(std::string& line){
    line = currentLine;
}

bool CFileReader::getNextLine(const std::string& keyword, const bool removeKeyword)
{
    bool r = false;
    while( stream && !stream->eof()){
        std::getline(*stream, currentLine);
        if( (keyword == "" || ((int)currentLine.find(keyword.c_str(),0))>=0) && (currentLine[0] != '#') ){
            trimWhiteSpace();
            if( removeKeyword ){
                std::string str;
                getStringValue(str);
            }
            r = true;
            break;
        }
    }
    return r;
}
bool CFileReader::getNextLine()
{
    bool l;
    bool r = !stream->eof();
    do{
        std::getline(*stream, currentLine);
        trimWhiteSpace();
        l = (currentLine == "");
    } while(l && !stream->eof());
    return ((r == false)?r:!l);
}

void CFileReader::getStringValue(std::string& str)
{
    int n=0;

    if( currentLine == "" || currentLine.length() == 0){
        str = "";
        return;
    }

    trimWhiteSpace();
    n = currentLine.find_first_of(" \t");
    if( n < 0 ){
        str = currentLine.c_str();
        currentLine.erase();
    } else {
        str = currentLine.substr(0,n).c_str();
        currentLine.erase(0,n);
    }
}
std::string CFileReader::getStringValue()
{
	std::string str;
    int n=0;

    if( currentLine == "" || currentLine.length() == 0){
        str = "";
        return str;
    }

    trimWhiteSpace();
    n = currentLine.find_first_of(" \t");
    if( n < 0 ){
        str = currentLine.c_str();
        currentLine.erase();
    } else {
        str = currentLine.substr(0,n).c_str();
        currentLine.erase(0,n);
    }
	return str;
}
double CFileReader::getDouble()
{
    float r;
    std::string str;
    getStringValue(str);

    r = atof(str.c_str());
    return r;
}

float CFileReader::getFloat()
{
    float r;
    std::string str;
    getStringValue(str);

    r = (float) atof(str.c_str());
    return r;
}
int CFileReader::getInt()
{
    int r;
    std::string str;
    getStringValue(str);

    r = atoi(str.c_str());
    return r;
}

void CFileReader::trimWhiteSpace()
{
   trimWhiteSpace(currentLine);
}

void CFileReader::trimWhiteSpace(std::string& line)
{
   std::string::size_type  notwhite = line.find_first_not_of(" \t\n");
   line.erase(0,notwhite);

   // trim trailing whitespace
   notwhite = line.find_last_not_of(" \t\n"); 
   line.erase(notwhite+1); 
}

void CFileReader::markPosition()
{
    if( stream )
        mark = stream->tellg();
}

void CFileReader::gotoToMark()
{
    if( stream )
        stream->seekg( mark );
}



