//////////////////////////////////////////////////////////////////////
// FileReader.h: interface for the CFileReader class.
// C.J. Cela, 2004
//
// V1.1, STL based
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILEREADER_H__640D97B2_2D37_4FFF_934C_086B44C6E586__INCLUDED_)
#define AFX_FILEREADER_H__640D97B2_2D37_4FFF_934C_086B44C6E586__INCLUDED_

#include <string>
#include <iostream>
#include <fstream>

class CFileReader  
{
public:
	CFileReader();
	virtual ~CFileReader();

    bool open(const std::string& filename, bool binary=false);
    bool open(const char* filename, bool binary=false);
    void close();
    bool isOpen();

    void gotoBof();
    bool getNextLine(const std::string& keyword, const bool removeKeyword = true);
    bool getNextLine();
    void getCurrentLine(std::string& line);
	std::string& getCurrentLine(){return currentLine;};

    void getStringValue(std::string& str);
	std::string getStringValue();
	double getDouble();
    float getFloat();
    int getInt();

    void markPosition(); //Mark this stream position
    void gotoToMark(); // Rewind stream to last marked position

    std::string getFileName();

    void trimWhiteSpace(); //Trims leading/trailing whitespace of current line
	void trimWhiteSpace(std::string& line);

private:
    std::ifstream* stream;
    std::string currentLine;
    std::string thisFile;

    std::streampos mark;


};

#endif // !defined(AFX_FILEREADER_H__640D97B2_2D37_4FFF_934C_086B44C6E586__INCLUDED_)
