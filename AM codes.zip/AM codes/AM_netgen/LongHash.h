// LongHash.h: interface for the CLongHash class.
// C.J. Cela, 2004
//
// Represents a large STL-compatible hash, calculated from the
// coordenates of a node or vertex.
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LONGHASH_H__87E81C00_70D6_4FE1_999C_116DC1474119__INCLUDED_)
#define AFX_LONGHASH_H__87E81C00_70D6_4FE1_999C_116DC1474119__INCLUDED_
#include <string>

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CLongHash  
{
public:
	CLongHash(int cx, int cy, int cz);
	CLongHash();
	virtual ~CLongHash();

    std::string getHash();
    std::string getHash(int x, int y, int z);
    std::string getHash(int x, int y, int z, int index);

    void setData(int d1,int d2, int d3){x=d1;y=d2;z=d3;};
    void getCoordinates(int nodePrefixLen, const std::string& hash, int&x, int&y, int&z);
private:
    int x;
    int y;
    int z;

};

#endif // !defined(AFX_LONGHASH_H__87E81C00_70D6_4FE1_999C_116DC1474119__INCLUDED_)
