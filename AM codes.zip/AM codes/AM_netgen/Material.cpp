// Material.cpp: implementation of the CMaterial class.
// Carlos J. Cela, 2004
//////////////////////////////////////////////////////////////////////
#include "Material.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMaterial::	CMaterial(double rx, double ex, double ry, double ey, double rz, double ez)

{
    rhox = rx;
	erx	 = ex;
    rhoy = ry;
	ery	 = ey;
    rhoz = rz;
	erz	 = ez;

}

CMaterial::~CMaterial()
{

}
