//////////////////////////////////////////////////////////////////////
// Material.h: interface for the CMaterial class.
// Carlos J. Cela, 2004
//////////////////////////////////////////////////////////////////////
// Represents a type of material. x, y & z are the complex 
// unitary impedance or admittance components for each axis.
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MATERIAL_H__03D17155_8BF1_44D8_8D25_0151EF49071D__INCLUDED_)
#define AFX_MATERIAL_H__03D17155_8BF1_44D8_8D25_0151EF49071D__INCLUDED_

class CMaterial  
{
public:
	CMaterial(double rx, double ex, double ry, double ey, double rz, double ez);
	virtual ~CMaterial();

	// The values below are the of a 1x1m section,
	// having a thickness of 1m
    double rhox, erx;	// resistivity and relative dielectric constant
    double rhoy, ery;	// resistivity and relative dielectric constant
    double rhoz, erz;	// resistivity and relative dielectric constant
};

#endif // !defined(AFX_MATERIAL_H__03D17155_8BF1_44D8_8D25_0151EF49071D__INCLUDED_)
