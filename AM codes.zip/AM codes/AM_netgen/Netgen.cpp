// NetGen.cpp: implementation of the CNetGen class.
// Carlos J. Cela, 2004
//////////////////////////////////////////////////////////////////////

#include "Netgen.h"
#include "Util.h"
#include "Network.h"
#include "Exception.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CNetGen::CNetGen(CMatrixParam* m)
{
  matrixParam = m;
}

CNetGen::~CNetGen()
{
}

void CNetGen::writeNetworkList()
{
  // Oprn network file
  openNetworkFile();
  
  // Write comments/header on file
  (*networkFile)<<"* Netgen V5x generated file\n";
  (*networkFile)<<"* param infile "<<matrixParam->inFile<<"\n* param meshfile "<<matrixParam->meshFile<<"\n";
  (*networkFile)<<"* param nodeprefix "<<matrixParam->nodePrefix<<"\n";

  //Named node list:
  std::map<std::string, std::string*>::iterator name;
  for( name = matrixParam->nodeName.begin(); name!=matrixParam->nodeName.end(); name++ )
    (*networkFile)<<"* param nodename "<<matrixParam->nodePrefix<<name->first<<" "<<*(name->second)<<"\n";

  (*networkFile)<<"\n* Start of network\n";

  // Write current sources & other active SPICE elements
  std::list<std::string*>::iterator csi = matrixParam->spice.begin();
  while( csi != matrixParam->spice.end() ){
    (*networkFile)<<*(*csi)<<"\n";
    csi++;
  }
  
  // Write voxels
  CNetwork network(matrixParam);
  network.loadAndWrite( (*networkFile));

 
  // Close file
  (*networkFile)<<"\n* End of network\n";
  closeNetworkFile();
}

void CNetGen::openNetworkFile()
{
  networkFile = new std::ofstream(matrixParam->networkFile.c_str());
  if( !networkFile->is_open() )
      throw CException("Error opening network file");
}

void CNetGen::closeNetworkFile()
{
    networkFile->close();
    delete networkFile;
}



