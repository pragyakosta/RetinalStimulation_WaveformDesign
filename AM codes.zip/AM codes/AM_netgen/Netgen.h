// NetGen.h: interface for the CNetGen class.
// Last revision: Carlos J. Cela, 2010
//////////////////////////////////////////////////////////////////////

#if !defined(NETGEN_H)
#define NETGEN_H

#include "Network.h"
#include "MatrixParam.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CNetGen  
{
public:
	CNetGen(CMatrixParam* m);
	virtual ~CNetGen();

    // Writes network file
    void writeNetworkList();

private:
    CMatrixParam* matrixParam; 

    // File for writing the network
    std::ofstream* networkFile;

    void openNetworkFile();
    void closeNetworkFile();
};

#endif // !defined(NETGEN_H)
