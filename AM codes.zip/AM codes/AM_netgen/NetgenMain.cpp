//////////////////////////////////////////////////////////////////////
// Carlos J. Cela, 2010
//////////////////////////////////////////////////////////////////////

#include "Netgen.h"
#include "Util.h"
#include "Exception.h"
#include "MatrixParam.h"
#include <string.h>

int main(int argc, char* argv[])
{
  int rValue = 0;
  CNetGen* netgen=0;

  util::msg("Netgen V 6.0\nCarlos J.Cela, 2010 (cjcela@gmail.com)\n\n");

  if( argc < 2 ){
  util::msg("Usage: netgen -f ifile\n");
  util::msg("  where:\n");
  util::msg("    ifile  = *.in file, without extension");
      return 1;
  }
  util::msg("BEGIN RUN\n");


  try{
    // Process command line options
    std::string ifilename=""; // Complete *.in  file name
    for( int x = 1; x < argc; x++ ){
      if( strcmp("-f",argv[x])==0 ){ 
        ifilename=argv[x+1];
        ifilename+=".in";
        x++;
      }
    }

    std::cout << ifilename;
    // Process *.in file
    CMatrixParam matrixParam = CMatrixParam(ifilename);

    // Create netgen now
    netgen = new CNetGen(&matrixParam);

    // Generate network file
    util::msg("Generating network..");
    netgen->writeNetworkList();
  }
  catch(CException e){
    // Nothing to do here - CException  
    // constructor will print/log details
    // about what went wrong..
     rValue = 2;
  }

  if(netgen) 
    delete netgen;

  util::msg("\nEND RUN\n");
	return rValue;
}
