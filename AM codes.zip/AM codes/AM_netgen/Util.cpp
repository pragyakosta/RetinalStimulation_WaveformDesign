//////////////////////////////////////////////////////////////////////
// Miscelaneous utility routines, used all over the place
// Carlos J. Cela, 2004
//////////////////////////////////////////////////////////////////////
#include "Util.h"
#include <string>
#include <fstream>
namespace util
{
    ////////////////////////////////////////////////
    // Standard in/out/log
    ////////////////////////////////////////////////
    std::ostream&  warning( const char* m)
    {
        std::cerr<<"[warning] ";
        if( m!=0 )
            std::cerr<<m<<"\n";
        return std::cerr;
    }
    std::ostream& msg( const char* m)
    {
        if( m!=0 )
            std::cout<<m<<"\n";
        return std::cout;
    }
    std::ostream& error( const char* m)
    {
        if( m!=0 )
            std::cerr<<"[Error]"<<m<<"\n";
        return std::cerr;
    }


    ////////////////////////////////////////////////
    // File functions
    ////////////////////////////////////////////////
	bool fileExists( const char* file)
    {
        std::ifstream stream(file);
        bool exists = stream.is_open();
        stream.close();
        return exists;
    }

    bool fileExist( const std::string file)
    {
        return fileExists(file.c_str());
    }
    std::string getPath(std::string fileName)
    {
        int p = fileName.find_last_of('/');
        if(p < 0)
            p = fileName.find_last_of('\\');
        return fileName.substr(0,p+1);
    }

}
