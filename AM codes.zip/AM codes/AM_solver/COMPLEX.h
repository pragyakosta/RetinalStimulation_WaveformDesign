#ifndef COMPLEX_TYPE_H
#define COMPLEX_TYPE_H

#include <complex>

#define COMPLEX_PRECISION double
#define COMPLEX std::complex< COMPLEX_PRECISION >

#endif

