#include "DynSparseRowArray.h"


//Don't really need a default constructor for the rows, since they'll be empty when built
//template<class T>
template<class T>
DynSparseRowArray<T>::DynSparseRowArray():vecSize(7),numEntries(0)
{
	vecEntries = new T [7];
	vecIndices = new unsigned [7];
}

template<class T>
DynSparseRowArray<T>::~DynSparseRowArray()
{
	
	if( vecSize != 0 )
	{
		delete [] vecEntries;
		delete [] vecIndices;
	}
	
}

template<class T>
T
DynSparseRowArray<T>::value(unsigned index)  
{
	if( numEntries != 0 )
	{
		for(unsigned i = 0; i < numEntries; i++)
			if( vecIndices[i] == index )
				return vecEntries[i];
	}

	return 0;
}



//refValue is used for the assignment of a value, note it returns a reference
//	this means that to return a 0, an entry must be created.
template<class T> T& DynSparseRowArray<T>::refValue(unsigned index)
{
	int pos = 0;
	if( numEntries != 0 ){
		while( pos < numEntries ){
			if( vecIndices[pos] == index )
				return vecEntries[pos];
			else if( vecIndices[pos] > index )
				return insert(index,0,pos);
			++pos;
		}
	}
	//If we get to this point we need to add something to the back of the vector
	return insert(index,0,pos);
}

template<class T> T& DynSparseRowArray<T>::insert(unsigned index, T value, unsigned arrayPos )
{
    //We slide arrayPos and everything behind arrayPos back one slot, then
	if( numEntries == vecSize ){
		T* tempPointerT = new T [vecSize + 1];
		unsigned* tempPointerU = new unsigned [vecSize + 1];
		unsigned bufpos = vecSize;
		while( bufpos > arrayPos ){
			tempPointerT[bufpos] = vecEntries[bufpos - 1];
			tempPointerU[bufpos] = vecIndices[bufpos - 1];
			bufpos--;
		}
		tempPointerT[arrayPos] = value;
		tempPointerU[arrayPos] = index;
		for( bufpos = 0; bufpos < arrayPos; bufpos++ ){
			tempPointerT[bufpos] = vecEntries[bufpos];
			tempPointerU[bufpos] = vecIndices[bufpos];
		}

		delete [] vecEntries;
		delete [] vecIndices;
		vecEntries = new T [ vecSize + 1];
		vecIndices = new unsigned [vecSize + 1];

		for( bufpos = 0; bufpos < vecSize + 1; bufpos++){
			vecEntries[bufpos] = tempPointerT[bufpos];
			vecIndices[bufpos] = tempPointerU[bufpos];
		}

		delete [] tempPointerT;
		delete [] tempPointerU;
		vecSize++;
		numEntries++;
	} else {
		unsigned bufpos = numEntries;
		while( bufpos > arrayPos ) {
			vecEntries[bufpos] = vecEntries[bufpos - 1];
			vecIndices[bufpos] = vecIndices[bufpos - 1];
			bufpos--;
		}
		vecEntries[arrayPos] = value;
		vecIndices[arrayPos] = index;
		numEntries++;
	}
	return vecEntries[arrayPos];
}

template<class T> T& DynSparseRowArray<T>::operator[](unsigned index)
{
	return refValue(index);
}


template<class T> void DynSparseRowArray<T>::clear()
{
	numEntries = 0;
}

template<class T> void DynSparseRowArray<T>::deleteAll()
{
	vecSize = 0;
	numEntries = 0;
	delete [] vecEntries;
	delete [] vecIndices;
	vecEntries = 0;
	vecIndices = 0;

}

template<class T> bool DynSparseRowArray<T>::empty()
{
	return ( numEntries == 0);
}


template<class T> int DynSparseRowArray<T>::changeSize(unsigned size)
{
	if( size == vecSize )
		return 1;

	T* tempPointerT = new T [ size ];
	unsigned* tempPointerU = new unsigned [ size ];

	unsigned a;
	if( size < vecSize )
		a = size;
	else
		a = vecSize;

	for( unsigned i = 0; i < a; i++ ){
		tempPointerT[i] = vecEntries[i];
		tempPointerU[i] = vecIndices[i];
	}

	delete [] vecEntries;
	delete [] vecIndices;

	vecEntries = new T [size];
	vecEntries = new unsigned [ size ];

	for( unsigned i = 0; i < a; i++){
		vecEntries[i] = tempPointerT[i];
		vecIndices[i] = tempPointerU[i];
	}

	delete [] tempPointerT;
	delete [] tempPointerU;

	if( numEntries > size )
		numEntries = size;

	vecSize = size;

	return 2;
}



template<class T> unsigned DynSparseRowArray<T>::length()
{
	return numEntries;
}


template<class T> void DynSparseRowArray<T>::fillCompRow(unsigned& count,int NZ,T* val,int* c)
{
	unsigned row_size = numEntries;
	//assert(count + row_size <= NZ );
	unsigned ct = count;
	for(unsigned i = 0; i < row_size; i++)
	{
		val[ct] = vecEntries[i];
		  c[ct] = vecIndices[i];
		++ct;
	}
	count = ct;

}


template<class T> unsigned DynSparseRowArray<T>::vecCapacity()
{
	return vecSize;
}


template<class T> unsigned DynSparseRowArray<T>::totalEntries()
{
	return numEntries;
}

