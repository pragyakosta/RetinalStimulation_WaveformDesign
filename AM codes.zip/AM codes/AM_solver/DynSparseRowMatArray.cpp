#include "DynSparseRowMatArray.h"

template<class T>DynSparseRowMatArray<T>::DynSparseRowMatArray(unsigned Rows, unsigned Cols):mat_storage_state(1)
{
	matDims[0] = Rows;
	matDims[1] = Cols;
	matRowsVec = new DynSparseRowArray<T> [ Rows ];
}


template<class T>DynSparseRowMatArray<T>::~DynSparseRowMatArray() 
{
	if( matRowsVec != 0 )
		deleteAll();
	matRowsVec = 0;
}

// Accessor using (row,col) indexing
// Note that this is just for accessing the element, NOT for modifying
template<class T> T DynSparseRowMatArray<T>::operator()(unsigned i, unsigned j)
{
	if( i >= matDims[0] || j >= matDims[1] )
		std::cout << "Error: Requested index ("<<i<<","<<j<<") exceeds matrix dimensions ["<<matDims[0]<<","<<matDims[1]<<"]\n";

	return matRowsVec[i].value(j);
}


template<class T> DynSparseRowArray<T>& DynSparseRowMatArray<T>::operator[](unsigned i)
{

	if( i > matDims[0] ){
		std::cout << "Error in matrix handling class. Index exceeded matrix dimensions" << std::endl;
		assert( i < matDims[0] );
	}
	return matRowsVec[i];
}


template<class T>void DynSparseRowMatArray<T>::clear()
{
	for( unsigned i = 0; i < matDims[0]; i++ )
		matRowsVec[i].clear();
}

template<class T> void DynSparseRowMatArray<T>::deleteAll()
{
	for( int i = 0; i < matDims[0]; i++ )
		matRowsVec[i].deleteAll();
	delete [] matRowsVec;
	matRowsVec = 0;
}


template<class T> void DynSparseRowMatArray<T>::compRowArrayFormat(int& M, int& N, int& NZ, T*& val, int*& r, int*& c)
{

	//About to declare these, so they'd better be empty
	assert( val == 0 && r == 0 && c == 0);

	M = matDims[0];
	N = matDims[1];
	NZ = nz();

	val = new T [NZ];
	r	= new int [M + 1];
	c   = new int [NZ];
	unsigned count = 0;

	for(unsigned i = 0; i < matDims[0]; i++ ){
		r[i] = count;
		matRowsVec[i].fillCompRow(count,NZ,val,c);
	}
	r[ M ] = NZ;
}

template<class T>unsigned DynSparseRowMatArray<T>::nz()
{
	unsigned NZ = 0;

	for( unsigned i = 0; i < matDims[0]; i++)
		NZ += matRowsVec[i].totalEntries();

	return NZ;
}


