// FastAccessMatrix.cpp: implementation of the CFastAccessMatrix class.
//
//////////////////////////////////////////////////////////////////////

#include "FastAccessMatrix.h"
#pragma warning (disable:4786)
#include <iostream>
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFastAccessMatrix::CFastAccessMatrix()
{
//test();
}

CFastAccessMatrix::~CFastAccessMatrix()
{

}

// sets _row & _col pointing to the first existing element.
// returns row # ; if matrix empty, returns -1
int CFastAccessMatrix::resetEnumeration()
{
	_row=_matrix.begin();
	if( _row!=_matrix.end() ){
		_pair=(* _row).second.begin();
		_col= (*_pair).first;
		return (*_row).first;
	} else {
		//_pair=z; //invalid value
		_col=-1;
		return -1;
	}
}

// advances to next populated row. returns row#,
// or -1 if no more rows
int CFastAccessMatrix::nextRow()
{
	_row++;
	if(_row==_matrix.end())
		return -1;

	_pair=(*_row).second.begin();
	_col= (*_pair).first;

	if(_pair!=(*_row).second.end())
		return (*_row).first;
	 else
		return -1;
};

// advances to row
bool CFastAccessMatrix::gotoRow(int row)
{
	_row=_matrix.find(row);

	if( _row!=_matrix.end()){
		_pair=(*_row).second.begin();
		return true;
	}

	// Does not exist
	return false;
}

// set value at row,col
void CFastAccessMatrix::set(int col, int row, double value)
{
	if(!gotoRow(row)){
		//Add row
		std::map<int,double> t;
		t[col]=value;
		_matrix[row]=t;
		_row=_matrix.find(row);
		_pair=(*_row).second.begin();
		_col= (*_pair).first;
		return;
	}

	// Set value
	((*_row).second)[col]=value;
}

double CFastAccessMatrix::get(int col, int row)
{
	double value;
	get(col, row, value);
	return value;
}

// get value at row,col
void CFastAccessMatrix::get(int col, int row, double& value)
{
	if(!gotoRow(row)){
		// Row does not exists
		value=0.0;
		return;
	}

	_pair=(*_row).second.find(col);

	// Row exists
	if(_pair!=(*_row).second.end()){
		value=(*_pair).second;
	} else {
		// Column does not exist
		value=0.0;
	}

	return;
}

// get next value and column position at this row
bool CFastAccessMatrix::getNextColAndValue(int & col, double & value)
{
	if(_pair==(*_row).second.end())
		return false;

	col=(*_pair).first;
	value=(*_pair).second;
	_pair++;
	return true;
}

bool CFastAccessMatrix::test()
{
	// Test matrix
	//
	//   0 1 2 3 4
	//
	//0  0 1 2 3 4
	//1  1 0 2 0 3
	//2  0 0 0 0 0
	//3  9 8 7 6 5
	//4  0 1 0 0 7
	//

	// Fill
	set(1,0,1);
	set(2,0,2);
	set(3,0,3);
	set(4,0,4);

	set(0,1,1);
	set(2,1,2);
	set(4,1,3);

	set(0,3,9);
	set(1,3,8);
	set(2,3,7);
	set(3,3,6);
	set(4,3,5);

	set(1,4,1);
	set(4,4,7);


	std::cout<<"0 1 2 3 4\n";
	std::cout<<"1 0 2 0 3\n";
	std::cout<<"0 0 0 0 0\n";
	std::cout<<"9 8 7 6 5\n";
	std::cout<<"0 1 0 0 7\n";
	std::cout<<"=======\n";


	// Retrieve & print (slow)
	int r,c;
	for(r=0;r<5;r++){
		for(c=0;c<5;c++){
			std::cout<<get(c,r)<<" ";
		}
		std::cout<<"\n";
	}
	std::cout<<"=======\n";

	// Retrieve & print (fast)
	double m[5*5];

	for(r=0;r<5;r++)
		for(c=0;c<5;c++)
			m[r*5+c]=0;

	double value;
	r=0;c=0;
	resetEnumeration();

	do{
		while(getNextColAndValue(c,value))
			m[r*5+c] = value;
		r=nextRow();
	} while (r!=-1);

	for(r=0;r<5;r++){
		for(c=0;c<5;c++){
			std::cout<<m[r*5+c]<<" ";
		}
		std::cout<<"\n";
	}

	return false;

}


