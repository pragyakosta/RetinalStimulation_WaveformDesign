/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*             ********   ***                                 SparseLib++    */
/*          *******  **  ***       ***      ***                              */
/*           *****      ***     ******** ********                            */
/*            *****    ***     ******** ********              R. Pozo        */
/*       **  *******  ***   **   ***      ***                 K. Remington   */
/*        ********   ********                                 A. Lumsdaine   */
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*                                                                           */
/*                                                                           */
/*                     SparseLib++ : Sparse Matrix Library                   */
/*                                                                           */
/*               National Institute of Standards and Technology              */
/*                        University of Notre Dame                           */
/*              Authors: R. Pozo, K. Remington, A. Lumsdaine                 */
/*                                                                           */
/*                                 NOTICE                                    */
/*                                                                           */
/* Permission to use, copy, modify, and distribute this software and         */
/* its documentation for any purpose and without fee is hereby granted       */
/* provided that the above notice appear in all copies and supporting        */
/* documentation.                                                            */
/*                                                                           */
/* Neither the Institutions (National Institute of Standards and Technology, */
/* University of Notre Dame) nor the Authors make any representations about  */
/* the suitability of this software for any purpose.  This software is       */
/* provided ``as is'' without expressed or implied warranty.                 */
/*                                                                           */
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#ifndef DIAGPRECOMP_H
#define DIAGPRECOMP_H



#include "vecdefs.h"
#include VECTOR_H



#include "comprow_complex.h"
#include "compcol_complex.h"

class DiagPreconditioner_COMPLEX {

 private:
  VECTOR_COMPLEX diag_;

 public:
  DiagPreconditioner_COMPLEX (const CompCol_Mat_COMPLEX &);
  DiagPreconditioner_COMPLEX (const CompRow_Mat_COMPLEX &);
  ~DiagPreconditioner_COMPLEX (void) { };
  VECTOR_COMPLEX solve (const VECTOR_COMPLEX &x) const;
  VECTOR_COMPLEX trans_solve (const VECTOR_COMPLEX &x) const;

  const COMPLEX&         diag(int i) const { return diag_(i); }
  COMPLEX&           diag(int i) { return diag_(i); }
};

#endif
