#ifndef PRE_H
#define PRE_H



#include "vecdefs.h"
#include VECTOR_H



#include "comprow_double.h"
#include "compcol_double.h"

class CPreconditioner {

 public:
	 CPreconditioner (){};
  //CPreconditioner (const CompCol_Mat_double &c);
  //CPreconditioner (const CompRow_Mat_double &c);
  virtual ~CPreconditioner (void) { };
  virtual VECTOR_double solve (const VECTOR_double &x) const =0;
  virtual VECTOR_double trans_solve (const VECTOR_double &x) const=0;
};

#endif
