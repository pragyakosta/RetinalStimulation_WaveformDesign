//*****************************************************************
// Iterative template routine -- SOR
// Carlos J. Cela, May 2010
//
// SOR solves the unsymmetric linear system Ax = b 
// using Successive Over-Relaxation method
//
//
// The return value indicates convergence within max_iter (input)
// iterations (0), or no convergence within max_iter iterations (1).
//
// Upon successful return, output arguments have the following values:
//  
//        x  --  approximate solution to Ax = b
// max_iter  --  the number of iterations performed before the
//               tolerance was reached
//      tol  --  the residual after the final iteration
//  
//*****************************************************************
#include "Timer.h"
#include <iostream>
#include <fstream>

template < class Matrix, class Vector, class Preconditioner, class Real >
int SOR(const Matrix &A, Vector &x, const Vector &b, int &max_iter, Real &tol)
{
	CTimer timer;
	std::ofstream file;
  
  // Approximate relaxation factor w
  Real c = cos(3.141592653589793238462643383279/A.getNumberOfRows())+cos(3.141592653589793238462643383279/A.getNumberOfColumns());
  Real w = 4.0/(2.0+sqrt(4.0+c*c));
  std::cout<<"Relaxation factor used: "<<w<<"\n";
  

  
  
	Real resid;
	Real resid_min=1e30;
	Real resid_min_period=1e30;
	Real resid_max_period=0;
	int iresid_min=0;
	int iresid_min_period=0;
	int iresid_max_period=0;

	file.open("residue.dat");

	Vector rho_1(1), rho_2(1), alpha(1), beta(1);
	Vector z, ztilde, p, ptilde, q, qtilde;

	Real normb = norm(b);
	Vector r = b - A * x;
	Vector rtilde = r;

	if (normb == 0.0)
		normb = 1;

	if ((resid = norm(r) / normb) <= tol) {
		tol = resid;
		max_iter = 0;
		return 0;
	}

	timer.start();
	for (int i = 1; i <= max_iter; i++) {
		z = M.solve(r);
		ztilde = M.trans_solve(rtilde);
		rho_1(0) = dot(z, rtilde);
		if (rho_1(0) == 0) { 
			tol = norm(r) / normb;
			max_iter = i;
			return 2;
		}
		if (i == 1) {
			p = z;
			ptilde = ztilde;
		} else {
			beta(0) = rho_1(0) / rho_2(0);
			p = z + beta(0) * p;
			ptilde = ztilde + beta(0) * ptilde;
		}
		q = A * p;
		qtilde = A.trans_mult(ptilde);
		alpha(0) = rho_1(0) / dot(ptilde, q);
		x += alpha(0) * p;
		r -= alpha(0) * q;
		rtilde -= alpha(0) * qtilde;

		rho_2(0) = rho_1(0);
		if ((resid = norm(r) / normb) < tol) {
			// Show some feedback
			std::cout<<"\rIteration: "<<i<<" Residue: "<<resid<<" ("<<resid_min<<")   ";


			tol = resid;
			max_iter = i;
			file.close();
			return 0;
		}
		std::cout<<"\rIteration: "<<i<<" Residue: "<<resid<<" ("<<resid_min<<")   ";;
		// Stats
		if(resid<resid_min){
			resid_min = resid;
			iresid_min=i;
		}
		if(resid>resid_max_period){
			resid_max_period = resid;
			iresid_max_period=i;
		}
		if(resid<resid_min_period){
			resid_min_period = resid;
			iresid_min_period=i;
		}

		// Display stats
		if(i%10000==0){
			int s=(int) timer.getTotal();
			timer.start();
			std::cout<<"\nMinimum residue: "<<resid_min<<" @ "<<iresid_min<<" "<<(float)s/10000.0<<" [s/it]\n";
		}

		// Save stats data
		file<<i<<" "<<resid<<"\n";
	}
	file.close();

	// Build gnuplot file
	// Plot residue vs iteration
	file.open ("residue.plt");
    file<<"plot 'residue.dat' using 1:2 title 'Residue vs iteration' with lines\n";
    file<<"set xlabel 'Iteration'\n";
	file<<"set ylabel 'Residue'\n"; 
	file<<"set grid\n";
	file<<"set terminal jpeg\n";
	file<<"set output 'residue.jpg'\n";
	file<<"replot\n";
	file<<"exit gnuplot\n";
	file.close();

	tol = resid;
	return 1;
}
  
