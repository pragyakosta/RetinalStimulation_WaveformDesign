//////////////////////////////////////////////////////////////////////////
// Solver_main.cpp
// Fast Portable Time-Domain Sparse Linear Solver
//////////////////////////////////////////////////////////////////////////
// * Carlos J. Cela, 2007 
//////////////////////////////////////////////////////////////////////////
// test params: -f hz -s 1e-4 -d 1e-3

#include "Ftdss.h"
#include <cstring>

// Static constant initialization
template<class T> const T DynSparseRowArray<T>::minVal = 1e-15;
template<class T> const T DynSparseRowMatArray<T>::minVal = 1e-15;


int main(int argc, char* argv[])
{
	int result=0; 
	CFtdss solver;

	// Version
	std::cout <<  "\n***************************************\n";
	std::cout <<  "Fast Time Domain Sparse Solver V3\n";
	std::cout <<  "***************************************\n";
	std::cout <<  "Carlos J. Cela (cjcela@gmail.com), 2010\n";
	std::cout <<  "This software uses NIST's SparseLib++ \n";
	std::cout <<  "and IML++ libraries.\n";
	std::cout <<  "***************************************\n";

	// Usage
	if(argc<=1 || strcmp("-?",argv[1])==0 || strcmp("-help",argv[1])==0 || strcmp("help",argv[1])==0 || strcmp("?",argv[1])==0){
		solver.showHelp();
		return 1;
	}
    

	// Setup and solve
	result = solver.run(argc,argv);

	return result;
}

