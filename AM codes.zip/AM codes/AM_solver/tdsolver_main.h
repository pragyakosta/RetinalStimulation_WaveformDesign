// solver_main.h: interface for the CSolver class.
// Carlos J.Cela, 2005
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SOLVER_MAIN_H__CB3D24AC_F3E3_4E79_AF91_813F2F3F0E9A__INCLUDED_)
#define AFX_SOLVER_MAIN_H__CB3D24AC_F3E3_4E79_AF91_813F2F3F0E9A__INCLUDED_



#endif //AFX_SOLVER_MAIN_H__CB3D24AC_F3E3_4E79_AF91_813F2F3F0E9A__INCLUDED_



