clc; close all; clear variables;

% Number of voxels along x,y,z directions of the model %
nx = 625;
ny = 425;   
nz = 200;

% where to plot 
ix = 284;
iy = 185;
iz = 34;

%% Read\Load files %%
% j = dlmread('P120_waveform3.j');
% j3D = reshape(j,ny,nz,nx);
% javg = dlmread('P120_waveform3.javg'); 
% javg3D = reshape(javg,ny,nz,nx);
% save('j_and_javg.mat','javg3D','j3D');

% Load voltage file %
load('j_and_javg.mat');

%% Plot the slices %%
figure(1); cx1 = -10; cx2 = 10;
subplot(1,2,1);imagesc(squeeze(log(j3D(:,:,ix)))); colorbar; axis xy; axis equal tight; caxis([cx1 cx2]);
subplot(1,2,2);imagesc(squeeze(log(javg3D(:,:,ix)))); colorbar; axis xy; axis equal tight; caxis([cx1 cx2]);

figure(2); cx1 = -10; cx2 = 10;
subplot(2,1,1);imagesc(squeeze(log(j3D(iy,:,:)))); colorbar; axis xy; axis equal tight; caxis([cx1 cx2]);
subplot(2,1,2);imagesc(squeeze(log(javg3D(iy,:,:)))); colorbar; axis xy; axis equal tight; caxis([cx1 cx2]);

figure(3); cx1 = 0; cx2 = 8;
subplot(2,1,1);imagesc(squeeze(log(j3D(:,iz,:)))); colorbar; axis xy; axis equal tight; caxis([cx1 cx2]);
subplot(2,1,2);imagesc(squeeze(log(javg3D(:,iz,:)))); colorbar; axis xy; axis equal tight; caxis([cx1 cx2]);

figure(4); cx1 = 0; cx2 = 8;
subplot(2,1,1);imagesc(squeeze(log(j3D(:,20,:)))); colorbar; axis xy; axis equal tight; %caxis([cx1 cx2]);
subplot(2,1,2);imagesc(squeeze(log(javg3D(:,20,:)))); colorbar; axis xy; axis equal tight; %caxis([cx1 cx2]);
