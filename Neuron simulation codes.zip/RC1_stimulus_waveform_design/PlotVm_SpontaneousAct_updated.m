% PlotVm_SpontaneousAct.m
%
% Kyle Loizos
% November 27, 2016
% Updated August 21, 2017 to include
% new stimulation waveform comparison
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all


% Current waveform

% Read in files
% CBC1 = dlmread('output/SpontaneousActivity/SingleBC_AiiOsc_Cell2.txt');
% AII1 = dlmread('output/SpontaneousActivity/SingleBC_AiiOsc_CellAii0.txt');
% GC1 = dlmread('output/SpontaneousActivity/SingleBC_AiiOsc_Cell21.txt');
% GC2 = dlmread('output/SpontaneousActivity/AllBC_AllAiiOsc_OnlyExc_Cell21.txt');
% GC3 = dlmread('output/SpontaneousActivity/AllBC_AllAiiOsc_AllSyn_Cell21.txt');
% 
% GCstim = dlmread('output/SpontaneousActivity/SingleBC_AiiOsc_Cell21_Stim.txt');
% %GCstim = dlmread('output/SpontaneousActivity/Stim_GC_AllBC_AiiOsc.txt');
% BCstim = dlmread('output/SpontaneousActivity/SingleBC_AiiOsc_Cell2_Stim.txt');

%% %%%%%%%%%%%%%%%%%%%%%%% 
% GCstim2_old = dlmread('voltage/output/20Aug2017_Symm_Syn50_Scale85/TwentyBC_AiiOsc_Cell21.txt');
% GCstim2_new = dlmread('voltage/output/20Aug2017_New_Syn50_Scale85/TwentyBC_AiiOsc_Cell21.txt');
GCstim2_old = dlmread('result symm/TwentyBC_AiiOsc_Cell21.txt');
GCstim2_new = dlmread('result nostim/TwentyBC_AiiOsc_Cell21.txt');

% Initiate parameters
dt = 0.02;
beg = 25;%75; %ms
s = beg/dt;
last = beg+170; %425;

f = last/dt;

% CBC1(:,1) = CBC1(:,1) - beg;

%t_stim = [1:100 100:101 101:103 103:118 118:120 120:121 121:123 123:138 138:140 140:141 141:143 143:158 158:160 160:161 161:163 163:178 178:180 180:181 181:183 183:198 198:200 200:201 201:203 203:218 218:220 220:221 221:223 223:238 238:500];
%cur = zeros(1,length(t_stim));
%cur(1:100)=0;
%cur(101:102)=-75;cur(103:105)=0;cur(106:121)=5;cur(122:124)=0;
%cur(125:126)=-75;cur(127:129)=0;cur(130:145)=5;cur(146:148)=0;
%cur(149:150)=-75;cur(151:153)=0;cur(154:169)=5;cur(170:172)=0;
%cur(173:174)=-75;cur(175:177)=0;cur(178:193)=5;cur(194:196)=0;
%cur(197:198)=-75;cur(199:201)=0;cur(202:217)=5;cur(218:220)=0;
%cur(221:222)=-75;cur(223:225)=0;cur(226:241)=5;cur(242:244)=0;
%cur(245:246)=-75;cur(247:249)=0;cur(250:265)=5;cur(267:length(t_stim))=0;
%t_stim = t_stim(76:length(t_stim));
%t_stim = t_stim-75;
%cur = cur(76:length(cur));


t_stim = [1:100 100:101 101:103 103:118 118:120 120:121 121:123 123:138 138:140 140:141 141:143 143:158 158:160 160:161 161:163 163:178 178:180 180:181 181:183 183:198 198:200 200:201 201:203 203:218 218:220 220:221 221:223 223:238 238:500];
cur = zeros(1,length(t_stim));
cur(1:100)=0;
cur(101:102)=-75;cur(103:105)=0;cur(106:121)=5;cur(122:124)=0;
cur(125:126)=-75;cur(127:129)=0;cur(130:145)=5;cur(146:148)=0;
cur(149:150)=-75;cur(151:153)=0;cur(154:169)=5;cur(170:172)=0;
cur(173:174)=-75;cur(175:177)=0;cur(178:193)=5;cur(194:196)=0;
cur(197:198)=-75;cur(199:201)=0;cur(202:217)=5;cur(218:length(t_stim))=0;
t_stim = t_stim(47:length(t_stim));
t_stim = t_stim-48;
cur = cur(47:length(cur));

t_stim2 = [1:100 100:101 101:102 102:103 103:120 120:121 121:122 122:123 123:140 140:141 141:142 142:143 143:160 160:161 161:162 162:163 163:180 180:181 181:182 182:183 183:200 200:201 201:203 203:218 218:220 220:221 221:223 223:238 238:500];
cur2 = zeros(1,length(t_stim2));
cur2(1:100)=0;
cur2(101:102)=-75;cur2(103:104)=0;cur2(105:106)=75;cur2(107:124)=0;
cur2(125:126)=-75;cur2(127:128)=0;cur2(129:130)=75;cur2(131:148)=0;
cur2(149:150)=-75;cur2(151:152)=0;cur2(153:154)=75;cur2(155:172)=0;
cur2(173:174)=-75;cur2(175:176)=0;cur2(177:178)=75;cur2(179:196)=0;
cur2(197:198)=-75;cur2(199:200)=0;cur2(201:202)=75;cur2(203:length(t_stim2))=0;
t_stim2 = t_stim2(47:length(t_stim2));
t_stim2 = t_stim2-48;
cur2 = cur2(47:length(cur2));

% Plot stimulation waveform
figure
plot(t_stim,cur,'LineWidth',2);
xlabel('Time (ms)'), ylabel('Current (\muA)');
axis([0 170 -80 10]);

figure
plot(t_stim2,cur2,'LineWidth',2);
xlabel('Time (ms)'), ylabel('Current (\muA)');
axis([0 0170 -80 80]);

% % Plot stimulated BC and GC
% figure
% plot(CBC1(s:f,1),BCstim(s:f,2),':','LineWidth',2);
% hold on
% plot(CBC1(s:f,1),GCstim(s:f,2),'LineWidth',2);
% hold off
% xlabel('Time (ms)'), ylabel('Membrane Voltage (mV)');
% axis([0 425 -80 40]);
% legend('CBC','GC');

% Plot stimulated GC - Compare with symmetric waveform
figure
plot(GCstim2_old(s:f,1)-25,GCstim2_old(s:f,2),'LineWidth',2);
xlabel('Time (ms)'), ylabel('Membrane Voltage (mV)');
axis([0 170 -80 40]);

figure
plot(GCstim2_new(s:f,1)-25,GCstim2_new(s:f,2),'LineWidth',2);
xlabel('Time (ms)'), ylabel('Membrane Voltage (mV)');
axis([0 170 -80 40]);

% % Plot coupled CBC and AII
% figure
% plot(CBC1(s:f,1),CBC1(s:f,2),':','LineWidth',2);
% hold on
% plot(CBC1(s:f,1),AII1(s:f,2),'LineWidth',2);
% xlabel('Time (ms)'), ylabel('Membrane Voltage (mV)');
% axis([0 425 -80 40]);
% legend('CBC','AII');
% 
% % Plot GC (single CBC<>AII)
% figure
% plot(CBC1(s:f,1),GC1(s:f,2),'LineWidth',2);
% xlabel('Time (ms)'), ylabel('Membrane Voltage (mV)');
% axis([0 425 -80 40]);
% 
% % Plot GC (20 CBC<>AII)
% figure
% plot(CBC1(s:f,1),GC2(s:f,2),'LineWidth',2);
% xlabel('Time (ms)'), ylabel('Membrane Voltage (mV)');
% axis([0 425 -80 40]);
% 
% % Plot GC (20 CBC<>AII)
% figure
% plot(CBC1(s:f,1),GC3(s:f,2),'LineWidth',2);
% xlabel('Time (ms)'), ylabel('Membrane Voltage (mV)');
% axis([0 425 -80 40]);

for i=1:4
FigHandle = figure(i);
set(FigHandle, 'Position', [100, 100, 1500, 500]);
set(findall(FigHandle,'-property','FontSize'),'FontSize',26);
end

