close all; clc; clear;

%% Read AM generated .v file
v = load("P120_waveform0_280x190y25z.v");

%% Process
v1 = zeros(180,size(v,2)); % initial zero padding
% 1st pulse
v1(78:79,:) = v(2:3,:);
v1(80,:) = v(5,:);
% 2nd pulse
v1(98:99,:) = v(2:3,:);
v1(100,:) = v(5,:);
% 3rd pulse
v1(118:119,:) = v(2:3,:);
v1(120,:) = v(5,:);
% 4th pulse
v1(138:139,:) = v(2:3,:);
v1(140,:) = v(5,:);
% 5th pulse
v1(158:159,:) = v(2:3,:);
v1(160,:) = v(5,:);

%% Write file
dlmwrite("P120_waveform0_280x190y25z_processed.v",v1," ");