clc;clear; close all;
v1 = load("P120_waveform0.v");
v2 = load("P120_waveform0_280x190y25z.v");

plot(v1(3,1:1000));
hold on;
plot(v2(3,1:1000));

figure()
plot(v1(4,:)-v2(4,:));
hold on;
plot(v1(2,:)-v2(2,:));
hold on;
plot(v1(3,:)-v2(3,:));